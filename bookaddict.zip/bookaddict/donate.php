<?php
include 'inc/db.php';

date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d H:i:s");
$user_id = (int)$_POST['user_id'];
$amount = (int)$_POST['amount'];

$sql = "insert into donations (user_id, amount, date_of_donation) values ($user_id, $amount, '$today_date' )";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "success";
}
else{
    echo "error";
}

?>