<?php
include 'inc/db.php';

$user_id = (int)$_POST['user_id'];
$data = array();

$sql = "select amount, date_of_donation from donations where user_id = $user_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>