<?php
include 'inc/db.php';

$book_id = (int)$_POST['book_id'];
$data = array();

$sql = "select users.full_name, ratings.star, ratings.given_date, ratings.feedback from ratings inner join users on users.user_id = ratings.user_id where ratings.book_id = $book_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>