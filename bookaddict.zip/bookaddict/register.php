<?php
include 'inc/db.php';

$full_name = $_POST['full_name'];
$email = strip_tags(htmlspecialchars($_POST['email']));
$password = $_POST['password'];
$phone = $_POST['phone'];

$sql = "select * from users where email = '$email' ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	echo "email_taken";
}
else{
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
	$qry = "insert into users (full_name, email, password, phone) values ('$full_name' , '$email', '$hashed_password', '$phone')";
			
	$result = mysqli_query($conn, $qry);
	if(!$result){
		echo "dbError";
	}
	else{
		$select_query = "select * from users where email = '$email' ";
        $result = mysqli_query($conn, $select_query);
        if(!$result){
            echo 'dbError2';
        }
        else{
            echo "success";
        }
	}
}
  
?>