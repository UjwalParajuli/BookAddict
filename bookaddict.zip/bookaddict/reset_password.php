<?php
include 'inc/db.php';

$new_password = $_POST['new_password'];
$email = $_POST['email'];

$sql = "select * from users where (email = '$email');";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $qry = "update users set password = '$hashed_password' where email = '$email' ";
            
    $result = mysqli_query($conn, $qry);
    if(!$result){
        echo "dbError";
    }
    else{
        
        echo "success"; 
    }
}
else{
    echo "email_not_found";
}
  
?>