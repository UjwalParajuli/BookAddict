<?php
include 'inc/db.php';

$book_id = (int)$_POST['book_id'];
$user_id = (int)$_POST['user_id'];
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d H:i:s");

$query = "select * from downloads where user_id = $user_id and book_id = $book_id ";
$result1 = mysqli_query($conn, $query);
if(mysqli_num_rows($result1) > 0){
    $qry1 = "update downloads set download_date = '$today_date' where user_id = $user_id and book_id = $book_id ";
    $result2 = mysqli_query($conn, $qry1);
    if($result2){
        echo 'success';
    }
    else{
        echo 'dbError';
    }
}
else{
    $qry = "insert into downloads (user_id, book_id, download_date) values ($user_id, $book_id, '$today_date')";
    $result = mysqli_query($conn, $qry);
    if($result){
        echo 'success';
    }
    else{
        echo 'dbError';
    }
}

?>