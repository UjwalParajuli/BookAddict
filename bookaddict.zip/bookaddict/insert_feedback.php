<?php
include 'inc/db.php';

$book_id = (int)$_POST['book_id'];
$user_id = (int)$_POST['user_id'];
$rating = floatval($_POST['rating']);
$feedback = $_POST['feedback'];
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d H:i:s");

$qry = "insert into ratings (user_id, book_id, star, feedback, given_date) values ($user_id, $book_id, $rating, '$feedback', '$today_date') ";
$result = mysqli_query($conn, $qry);
if($result){
    echo 'success';
}
else{
    echo 'dbError';
}
?>