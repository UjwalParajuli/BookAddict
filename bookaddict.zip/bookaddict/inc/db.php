<?php
$servername = "localhost";
$dbname = "book_addict";
$uname = "root";
$pass = "";
$conn = mysqli_connect($servername, $uname, $pass, $dbname);
if (!$conn) {
    die("Connection failed!");
}
?>